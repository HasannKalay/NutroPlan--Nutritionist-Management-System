﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            pictureBox1 = new PictureBox();
            txtusername = new TextBox();
            txtpassword = new TextBox();
            pictureBox2 = new PictureBox();
            pictureBox3 = new PictureBox();
            btnlog = new Button();
            button2 = new Button();
            btnclose = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(88, 31);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(152, 98);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // txtusername
            // 
            txtusername.BackColor = Color.Gray;
            txtusername.BorderStyle = BorderStyle.None;
            txtusername.Font = new Font("Calibri", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 162);
            txtusername.Location = new Point(88, 181);
            txtusername.Name = "txtusername";
            txtusername.Size = new Size(177, 22);
            txtusername.TabIndex = 1;
            txtusername.Text = "Username";
            txtusername.MouseClick += txtusername_MouseClick;
            txtusername.TextChanged += textBox1_TextChanged;
            txtusername.MouseEnter += txtusername_MouseEnter;
            // 
            // txtpassword
            // 
            txtpassword.BackColor = Color.Gray;
            txtpassword.BorderStyle = BorderStyle.None;
            txtpassword.Font = new Font("Calibri", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 162);
            txtpassword.Location = new Point(88, 253);
            txtpassword.Name = "txtpassword";
            txtpassword.Size = new Size(177, 22);
            txtpassword.TabIndex = 2;
            txtpassword.Text = "Password";
            txtpassword.MouseClick += txtpassword_MouseClick;
            txtpassword.TextChanged += textBox2_TextChanged;
            txtpassword.KeyPress += txtpassword_KeyPress;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(40, 181);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(42, 22);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 3;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click_1;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(40, 253);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(42, 22);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 4;
            pictureBox3.TabStop = false;
            pictureBox3.Click += pictureBox3_Click;
            // 
            // btnlog
            // 
            btnlog.BackColor = Color.IndianRed;
            btnlog.FlatStyle = FlatStyle.Popup;
            btnlog.Font = new Font("Calibri", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 162);
            btnlog.Location = new Point(52, 320);
            btnlog.Name = "btnlog";
            btnlog.Size = new Size(225, 46);
            btnlog.TabIndex = 5;
            btnlog.Text = "Login";
            btnlog.UseVisualStyleBackColor = false;
            btnlog.Click += btnlog_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.DarkOrange;
            button2.FlatStyle = FlatStyle.Popup;
            button2.Font = new Font("Calibri", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 162);
            button2.ForeColor = Color.Black;
            button2.Location = new Point(52, 388);
            button2.Name = "button2";
            button2.Size = new Size(225, 46);
            button2.TabIndex = 6;
            button2.Text = "Signup";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // btnclose
            // 
            btnclose.AutoSize = true;
            btnclose.BackColor = SystemColors.ButtonHighlight;
            btnclose.FlatStyle = FlatStyle.Popup;
            btnclose.Font = new Font("Calibri", 18F, FontStyle.Bold, GraphicsUnit.Point, 162);
            btnclose.ForeColor = Color.Brown;
            btnclose.Location = new Point(287, 0);
            btnclose.Name = "btnclose";
            btnclose.Size = new Size(45, 47);
            btnclose.TabIndex = 7;
            btnclose.Text = "X";
            btnclose.UseVisualStyleBackColor = false;
            btnclose.Click += btnclose_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Gray;
            ClientSize = new Size(331, 497);
            Controls.Add(btnclose);
            Controls.Add(button2);
            Controls.Add(btnlog);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox2);
            Controls.Add(txtpassword);
            Controls.Add(txtusername);
            Controls.Add(pictureBox1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private TextBox txtusername;
        private TextBox txtpassword;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private Button btnlog;
        private Button button2;
        private Button btnclose;
    }
}
