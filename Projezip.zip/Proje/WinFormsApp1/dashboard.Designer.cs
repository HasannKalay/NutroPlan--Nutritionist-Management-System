﻿namespace WinFormsApp1
{
    partial class dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(dashboard));
            menuStrip1 = new MenuStrip();
            menuStrip2 = new MenuStrip();
            meetingToolStripMenuItem1 = new ToolStripMenuItem();
            addMeetingToolStripMenuItem = new ToolStripMenuItem();
            viewMeetingToolStripMenuItem = new ToolStripMenuItem();
            patienToolStripMenuItem = new ToolStripMenuItem();
            patientProfileToolStripMenuItem = new ToolStripMenuItem();
            personalInformationToolStripMenuItem = new ToolStripMenuItem();
            dietListToolStripMenuItem = new ToolStripMenuItem();
            addPatientToolStripMenuItem = new ToolStripMenuItem();
            listToolStripMenuItem = new ToolStripMenuItem();
            createListToolStripMenuItem = new ToolStripMenuItem();
            editListToolStripMenuItem = new ToolStripMenuItem();
            exitToolStripMenuItem = new ToolStripMenuItem();
            menuStrip2.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.BackColor = SystemColors.Highlight;
            menuStrip1.ImageScalingSize = new Size(20, 20);
            menuStrip1.Location = new Point(0, 72);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(1114, 24);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            menuStrip1.ItemClicked += menuStrip1_ItemClicked;
            // 
            // menuStrip2
            // 
            menuStrip2.BackColor = SystemColors.Highlight;
            menuStrip2.BackgroundImageLayout = ImageLayout.Stretch;
            menuStrip2.ImageScalingSize = new Size(20, 20);
            menuStrip2.Items.AddRange(new ToolStripItem[] { meetingToolStripMenuItem1, patienToolStripMenuItem, listToolStripMenuItem, exitToolStripMenuItem });
            menuStrip2.Location = new Point(0, 0);
            menuStrip2.Name = "menuStrip2";
            menuStrip2.Size = new Size(1114, 72);
            menuStrip2.TabIndex = 1;
            menuStrip2.Text = "menuStrip2";
            // 
            // meetingToolStripMenuItem1
            // 
            meetingToolStripMenuItem1.DropDownItems.AddRange(new ToolStripItem[] { addMeetingToolStripMenuItem, viewMeetingToolStripMenuItem });
            meetingToolStripMenuItem1.Image = (Image)resources.GetObject("meetingToolStripMenuItem1.Image");
            meetingToolStripMenuItem1.ImageScaling = ToolStripItemImageScaling.None;
            meetingToolStripMenuItem1.Name = "meetingToolStripMenuItem1";
            meetingToolStripMenuItem1.Size = new Size(142, 68);
            meetingToolStripMenuItem1.Text = "Meeting";
            meetingToolStripMenuItem1.Click += meetingToolStripMenuItem1_Click;
            // 
            // addMeetingToolStripMenuItem
            // 
            addMeetingToolStripMenuItem.BackgroundImageLayout = ImageLayout.Stretch;
            addMeetingToolStripMenuItem.Image = (Image)resources.GetObject("addMeetingToolStripMenuItem.Image");
            addMeetingToolStripMenuItem.ImageScaling = ToolStripItemImageScaling.None;
            addMeetingToolStripMenuItem.Name = "addMeetingToolStripMenuItem";
            addMeetingToolStripMenuItem.Size = new Size(268, 70);
            addMeetingToolStripMenuItem.Text = "Add Meeting";
            addMeetingToolStripMenuItem.Click += addMeetingToolStripMenuItem_Click;
            // 
            // viewMeetingToolStripMenuItem
            // 
            viewMeetingToolStripMenuItem.Image = (Image)resources.GetObject("viewMeetingToolStripMenuItem.Image");
            viewMeetingToolStripMenuItem.ImageScaling = ToolStripItemImageScaling.None;
            viewMeetingToolStripMenuItem.Name = "viewMeetingToolStripMenuItem";
            viewMeetingToolStripMenuItem.Size = new Size(268, 70);
            viewMeetingToolStripMenuItem.Text = "View Meeting";
            // 
            // patienToolStripMenuItem
            // 
            patienToolStripMenuItem.BackgroundImageLayout = ImageLayout.Stretch;
            patienToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { patientProfileToolStripMenuItem, addPatientToolStripMenuItem });
            patienToolStripMenuItem.Image = (Image)resources.GetObject("patienToolStripMenuItem.Image");
            patienToolStripMenuItem.ImageScaling = ToolStripItemImageScaling.None;
            patienToolStripMenuItem.Name = "patienToolStripMenuItem";
            patienToolStripMenuItem.Size = new Size(138, 68);
            patienToolStripMenuItem.Text = "Patients";
            patienToolStripMenuItem.Click += patienToolStripMenuItem_Click;
            // 
            // patientProfileToolStripMenuItem
            // 
            patientProfileToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { personalInformationToolStripMenuItem, dietListToolStripMenuItem });
            patientProfileToolStripMenuItem.Image = (Image)resources.GetObject("patientProfileToolStripMenuItem.Image");
            patientProfileToolStripMenuItem.ImageScaling = ToolStripItemImageScaling.None;
            patientProfileToolStripMenuItem.Name = "patientProfileToolStripMenuItem";
            patientProfileToolStripMenuItem.Size = new Size(268, 70);
            patientProfileToolStripMenuItem.Text = "Patient Profile";
            patientProfileToolStripMenuItem.Click += patientProfileToolStripMenuItem_Click;
            // 
            // personalInformationToolStripMenuItem
            // 
            personalInformationToolStripMenuItem.Image = (Image)resources.GetObject("personalInformationToolStripMenuItem.Image");
            personalInformationToolStripMenuItem.ImageScaling = ToolStripItemImageScaling.None;
            personalInformationToolStripMenuItem.Name = "personalInformationToolStripMenuItem";
            personalInformationToolStripMenuItem.Size = new Size(241, 38);
            personalInformationToolStripMenuItem.Text = "Personal Information";
            personalInformationToolStripMenuItem.Click += personalInformationToolStripMenuItem_Click;
            // 
            // dietListToolStripMenuItem
            // 
            dietListToolStripMenuItem.Image = (Image)resources.GetObject("dietListToolStripMenuItem.Image");
            dietListToolStripMenuItem.ImageScaling = ToolStripItemImageScaling.None;
            dietListToolStripMenuItem.Name = "dietListToolStripMenuItem";
            dietListToolStripMenuItem.Size = new Size(241, 38);
            dietListToolStripMenuItem.Text = "Diet List";
            // 
            // addPatientToolStripMenuItem
            // 
            addPatientToolStripMenuItem.Image = (Image)resources.GetObject("addPatientToolStripMenuItem.Image");
            addPatientToolStripMenuItem.ImageScaling = ToolStripItemImageScaling.None;
            addPatientToolStripMenuItem.Name = "addPatientToolStripMenuItem";
            addPatientToolStripMenuItem.Size = new Size(268, 70);
            addPatientToolStripMenuItem.Text = "Add Patient";
            addPatientToolStripMenuItem.Click += addPatientToolStripMenuItem_Click;
            // 
            // listToolStripMenuItem
            // 
            listToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { createListToolStripMenuItem, editListToolStripMenuItem });
            listToolStripMenuItem.Image = (Image)resources.GetObject("listToolStripMenuItem.Image");
            listToolStripMenuItem.ImageScaling = ToolStripItemImageScaling.None;
            listToolStripMenuItem.Name = "listToolStripMenuItem";
            listToolStripMenuItem.Size = new Size(109, 68);
            listToolStripMenuItem.Text = "List";
            listToolStripMenuItem.Click += listToolStripMenuItem_Click;
            // 
            // createListToolStripMenuItem
            // 
            createListToolStripMenuItem.Image = (Image)resources.GetObject("createListToolStripMenuItem.Image");
            createListToolStripMenuItem.ImageScaling = ToolStripItemImageScaling.None;
            createListToolStripMenuItem.Name = "createListToolStripMenuItem";
            createListToolStripMenuItem.Size = new Size(205, 70);
            createListToolStripMenuItem.Text = "Create List";
            // 
            // editListToolStripMenuItem
            // 
            editListToolStripMenuItem.Image = (Image)resources.GetObject("editListToolStripMenuItem.Image");
            editListToolStripMenuItem.ImageScaling = ToolStripItemImageScaling.None;
            editListToolStripMenuItem.Name = "editListToolStripMenuItem";
            editListToolStripMenuItem.Size = new Size(205, 70);
            editListToolStripMenuItem.Text = "Edit List";
            // 
            // exitToolStripMenuItem
            // 
            exitToolStripMenuItem.Image = (Image)resources.GetObject("exitToolStripMenuItem.Image");
            exitToolStripMenuItem.ImageScaling = ToolStripItemImageScaling.None;
            exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            exitToolStripMenuItem.Size = new Size(111, 68);
            exitToolStripMenuItem.Text = "Exit";
            exitToolStripMenuItem.Click += exitToolStripMenuItem_Click;
            // 
            // dashboard
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Highlight;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1114, 557);
            Controls.Add(menuStrip1);
            Controls.Add(menuStrip2);
            FormBorderStyle = FormBorderStyle.None;
            MainMenuStrip = menuStrip1;
            Name = "dashboard";
            Text = "dashboard";
            WindowState = FormWindowState.Maximized;
            Load += dashboard_Load;
            menuStrip2.ResumeLayout(false);
            menuStrip2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private MenuStrip menuStrip2;
        private ToolStripMenuItem meetingToolStripMenuItem1;
        private ToolStripMenuItem addMeetingToolStripMenuItem;
        private ToolStripMenuItem viewMeetingToolStripMenuItem;
        private ToolStripMenuItem patienToolStripMenuItem;
        private ToolStripMenuItem patientProfileToolStripMenuItem;
        private ToolStripMenuItem personalInformationToolStripMenuItem;
        private ToolStripMenuItem dietListToolStripMenuItem;
        private ToolStripMenuItem addPatientToolStripMenuItem;
        private ToolStripMenuItem listToolStripMenuItem;
        private ToolStripMenuItem createListToolStripMenuItem;
        private ToolStripMenuItem editListToolStripMenuItem;
        private ToolStripMenuItem exitToolStripMenuItem;
    }
}