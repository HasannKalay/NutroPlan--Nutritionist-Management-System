﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1

{
    
    public partial class AddPatient : Form
    {

         public static SqlConnection con = new SqlConnection("Data Source=ALP; Initial Catalog=nutroplan; Integrated Security=TRUE; TrustServerCertificate=True");
        public AddPatient()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {


        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void buttoncancel_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("This will delete your data", "Are you sure?", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) == DialogResult.OK)
            {
                this.Close();
            }
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "" && textBox4.Text != "" && textBox5.Text != "")
            {
                String Name = textBox1.Text;
                String Surname = textBox2.Text;
                Int64 Phonenumber = Int64.Parse(textBox3.Text);
                String Birthdate = dateTimePicker1.Text;
                Int64 Weight = Int64.Parse(textBox4.Text);
                Int64 Height =Int64.Parse(textBox5.Text);
                
                
 
                SqlCommand cmd = new SqlCommand("select * from AddPatient",con);
                cmd.Connection = con;
                con.Open();
                cmd.CommandText = "insert into AddPatient (Name,Surname,Phonenumber,Birthdate,Weight,Height) values ('" + Name + "', '" + Surname + "'," + Phonenumber + ",'" + Birthdate.ToString() + "'," + Weight + "," + Height + ")";
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Data Saved.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();

            }
            else
            {
                MessageBox.Show("Empty Field not allowed", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
    }
}